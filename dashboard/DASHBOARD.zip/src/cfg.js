module.exports = {
    // API_LINK: 'http://localhost:5000/api'
    API_LINK: 'https://kurgan.na4u.ru/api'
}